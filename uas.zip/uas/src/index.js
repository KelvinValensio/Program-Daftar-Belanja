import express from "express";
import mysql from "mysql";
import path from "path";
import ejs from "ejs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = 3000;

// Middleware for processing form data
app.use(express.urlencoded({ extended: true }));

// Konfigurasi koneksi MySQL
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "db_tugus",
});

// Koneksi ke MySQL
db.connect((err) => {
  if (err) {
    console.error("Koneksi MySQL Gagal: " + err.message);
  } else {
    console.log("Terhubung ke MySQL");
  }
});

app.set("views", path.join(__dirname, "../views"));

// Atur berkas HTML sebagai berkas tampilan utama
app.set("view engine", "html");

app.engine("html", ejs.renderFile);
// Rute untuk halaman utama
app.get("/", (req, res) => {
  let groceriesQuery = "",
    categoriesQuery = "";

  if (!req.query.search || req.query.search === "") {
    // Contoh query ke MySQL untuk mengambil data dari tabel products
    groceriesQuery = `SELECT tb_grocery.*, tb_category.name AS category_name FROM tb_grocery INNER JOIN tb_category ON tb_grocery.id_category = tb_category.id `;

    // Contoh query ke MySQL untuk mengambil data dari tabel categories
    categoriesQuery = `SELECT * FROM tb_category`;
  } else {
    let search = `%${req.query.search}%`;
    // Contoh query ke MySQL untuk mengambil data dari tabel products
    groceriesQuery = `SELECT tb_grocery.*, tb_category.name AS category_name FROM tb_grocery INNER JOIN tb_category ON tb_grocery.id_category = tb_category.id WHERE tb_grocery.name like '${search}' OR tb_category.name like '${search}'`;

    // Contoh query ke MySQL untuk mengambil data dari tabel categories
    categoriesQuery = `SELECT * FROM tb_category WHERE name like '${search}'`;
  }

  // Eksekusi kedua query secara bersamaan
  db.query(groceriesQuery, (errgroceries, resultsgroceries) => {
    if (errgroceries) {
      return res
        .status(500)
        .send("Error dalam mengambil data belanjaan dari MySQL");
    }

    db.query(categoriesQuery, (errCategories, resultsCategories) => {
      if (errCategories) {
        return res
          .status(500)
          .send("Error dalam mengambil data kategori dari MySQL");
      }

      const totalPrice = resultsgroceries.reduce(
        (acc, row) => acc + row.price,
        0
      );

      // Gabungkan hasil query
      const combinedData = {
        groceries: resultsgroceries,
        categories: resultsCategories,
        total: totalPrice,
      };

      // Kirim data gabungan sebagai respons JSON
      res.render("index", combinedData);
    });
  });
});

app.get("/delete-category", (req, res) => {
  db.query(`DELETE FROM tb_category WHERE id = ${req.query.id}`, (err) => {
    if (err) {
      return res.status(500).send("Error dalam menghapus data kategori");
    }

    res.redirect("/");
  });
});

app.get("/delete-grocery", (req, res) => {
  db.query(`DELETE FROM tb_grocery WHERE id = ${req.query.id}`, (err) => {
    if (err) {
      return res.status(500).send("Error dalam menghapus data belanjaan");
    }

    res.redirect("/");
  });
});

app.get("/create-category", (req, res) => {
  res.render("create-category");
});

app.post("/create-category", (req, res) => {
  const name = req.body.name;
  db.query(`insert into tb_category (name) values ('${name}')`, (err) => {
    if (err) {
      return res.status(500).send("Error dalam memasukan data kategori");
    }

    res.redirect("/");
  });
});

app.get("/create-grocery", (req, res) => {
  db.query(`select * from tb_category`, (err, results) => {
    if (err) {
      return res.status(500).send("Error dalam memanggil data kategori");
    }

    res.render("create-grocery", { data: results });
  });
});

app.post("/create-grocery", (req, res) => {
  const { name, category, price } = req.body;

  // Use parameterized query to avoid SQL injection
  const sql =
    "INSERT INTO tb_grocery (id_category, name, price) VALUES (?, ?, ?)";
  db.query(sql, [category, name, price], (err, result) => {
    if (err) {
      console.error("Error in inserting grocery data:", err);
      return res.status(500).send("Error in inserting grocery data.");
    }

    res.redirect("/");
  });
});

app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});
